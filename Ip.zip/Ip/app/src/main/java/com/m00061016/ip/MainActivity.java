package com.m00061016.ip;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void calc(View v) {


        // Calculando la cantidad de host para la red
        //Y obteniendo la maxima cantidad de host
        EditText mask;
        String numbmask;

        TextView cant_host;
        int canthost;
        mask = (EditText) findViewById(R.id.mask_numb);
        numbmask = mask.getText().toString();
        if (Integer.parseInt(mask.getText().toString()) == 0) {
            numbmask = "24";
        }


        //Formula para calcular la cantidad de host disponibles en una red a partir de la mascara.
        canthost = (int) (Math.pow(2, 32 - Integer.parseInt(numbmask))) - (2);

        cant_host = findViewById(R.id.cant_host);
        cant_host.setText("" + canthost);

        //Calculando el ID de red

        EditText ipentry = (EditText) findViewById(R.id.ip);
        TextView netid = (TextView) findViewById(R.id.net_id);
        String ipcomp = ipentry.getText().toString();
        String[] ip = ipcomp.split("[.]");

        //Variables que se utilizaran para los procesos: -Netid
        int ip1, ip2, ip3, ip4;
        ip1 = Integer.parseInt(ip[0]);
        ip2 = Integer.parseInt(ip[1]);
        ip3 = Integer.parseInt(ip[2]);
        ip4 = Integer.parseInt(ip[3]);
        int[] iparray = new int[32];

        int mascara1 = 0, mascara2 = 0, mascara3 = 0, mascara4 = 0;
        int netid1, netid2, netid3, netid4;

        //Llenando el array de la mascara de red
        for (int i = 0; i < Integer.parseInt(numbmask); i++) {
            iparray[i] = 1;
        }
        for (int i = Integer.parseInt(numbmask); i < 31; i++) {
            iparray[i] = 0;
        }
        //Calculando el valor de cada octeto para la mascara de red
        for (int i = 0; i < 8; i++) {
            if (iparray[i] == 1) {
                mascara1 = mascara1 + (int) Math.pow(2, 7 - i);
            }
            if (iparray[i + 8] == 1) {
                mascara2 = mascara2 + (int) Math.pow(2, 7 - i);
            }
            if (iparray[i + 16] == 1) {
                mascara3 = mascara3 + (int) Math.pow(2, 7 - i);
            }
            if (iparray[i + 24] == 1) {
                mascara4 = mascara4 + (int) Math.pow(2, 7 - i);
            }
        }

        //Efectuando la operacion booleana AND para calcular el id de red
        netid1 = ip1 & mascara1;
        netid2 = ip2 & mascara2;
        netid3 = ip3 & mascara3;
        netid4 = ip4 & mascara4;
        netid.setText("" + netid1 + "." + netid2 + "." + netid3 + "." + netid4);

        //Efectuando la operacion booleana OR para calcular el broadcast de la red con la mascara invertida
        int br1 = 0, br2 = 0, br3 = 0, br4 = 0;
        int[] brarray = new int[32];
        int broadcast1, broadcast2, broadcast3, broadcast4;

        //Inviertiendo la mascara de red
        for (int i = 0; i < 32; i++) {
            if (iparray[i] == 0) {
                brarray[i] = 1;
            } else if (iparray[i] == 1) {
                brarray[i] = 0;
            }
        }

        //Calculando los valores respectivos de cada octeto
        for (int i = 0; i < 8; i++) {
            if (brarray[i] == 1) {
                br1 = br1 + (int) Math.pow(2, 7 - i);
            }
            if (brarray[i + 8] == 1) {
                br2 = br2 + (int) Math.pow(2, 7 - i);
            }
            if (brarray[i + 16] == 1) {
                br3 = br3 + (int) Math.pow(2, 7 - i);
            }
            if (brarray[i + 24] == 1) {
                br4 = br4 + (int) Math.pow(2, 7 - i);
            }
        }

        //Efectuando la operacion OR para calcular el valor de cada octeto del broadcast
        broadcast1 = ip1 | br1;
        broadcast2 = ip2 | br2;
        broadcast3 = ip3 | br3;
        broadcast4 = ip4 | br4;

        //Asignandole los valores al broadcast
        TextView broadcast = (TextView) findViewById(R.id.ip_broadcast);
        broadcast.setText("" + broadcast1 + "." + broadcast2 + "." + broadcast3 + "." + broadcast4);

        //Calculando la parte de red y host
        TextView partered, partehost;
        partehost = (TextView) findViewById(R.id.parte_host);
        partered = (TextView) findViewById(R.id.parte_red);
        int host1,host2,host3,host4;

        partered.setText(netid1+"."+netid2+"."+netid3+"."+netid4);

        host1 = ip1 & br1;
        host2 = ip2 & br2;
        host3 = ip3 & br3;
        host4 = ip4 & br4;

        partehost.setText(host1+"."+host2+"."+host3+"."+host4);
    }
}
